import 'package:flutter/material.dart';

const myTextColor = Color.fromARGB(255, 183, 166, 208);
const myBtnColor = Color.fromARGB(255, 246, 52, 119);
const myPrimaryColor = Color.fromARGB(255, 208, 120, 171);
const mySecondryTextColor = Color.fromARGB(255, 51, 49, 54);
const starColor = Color.fromARGB(255, 235, 192, 223);
